import sys

def remove_host(ip):
    hosts_file = '/app/hosts'
    try:
        with open(hosts_file, 'r') as file:
            lines = file.readlines()
        with open(hosts_file, 'w') as file:
            for line in lines:
                if not line.startswith(ip):
                    file.write(line)
                else:
                    print(f"Removed line: {line.strip()}")
        print(f"Host {ip} removed successfully.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 remove_hosts.py <IP>")
        sys.exit(1)

    ip_address = sys.argv[1]
    remove_host(ip_address)

