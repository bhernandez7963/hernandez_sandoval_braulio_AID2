import sys

def create_or_update_hosts(ip_address, user, password):
    hosts_file_path = '/app/hosts'
    header = "[targets]\n"
    entry = f"{ip_address} ansible_user={user} ansible_ssh_pass={password}\n"

    try:
        # Verificar si el archivo hosts existe, si no, crearlo
        with open(hosts_file_path, 'a+') as file:
            file.seek(0)
            content = file.read()

            if header not in content:  # Comprueba si el encabezado no está presente
                file.write(header)

            if entry not in content:  # Añadir la nueva entrada si no está presente
                file.write(entry)
                print(f"Added IP {ip_address} to hosts file at: {hosts_file_path}")

    except Exception as e:
        print(f"Failed to write to hosts file: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python3 create_hosts.py <IP> <user> <password>")
        sys.exit(1)

    ip_address = sys.argv[1]
    user = sys.argv[2]
    password = sys.argv[3]
    create_or_update_hosts(ip_address, user, password)

